<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'theme' => '',
    'inline' => null,
    'number' => null,
    'column' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'inline' => null,
    'number' => null,
    'column' => '',
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'inline' => null,
    'number' => null,
    'column' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php if(filled($number)): ?>
        <div class="<?php echo e($theme->baseClass); ?>" style="<?php echo e($theme->baseStyle); ?>">
            <div>
                <input
                    data-id="<?php echo e(data_get($number, 'field')); ?>"
                    wire:model.debounce.800ms="filters.number_start.<?php echo e(data_get($number, 'dataField')); ?>"
                    wire:input.debounce.800ms="filterNumberStart('<?php echo e(data_get($number, 'dataField')); ?>', $event.target.value,'<?php echo e(addslashes(data_get($number, 'thousands'))); ?>','<?php echo e(addslashes(data_get($number, 'decimal'))); ?>','<?php echo e(data_get($number, 'label')); ?>')"
                    <?php if($inline): ?> style="<?php echo e($theme->inputStyle); ?> <?php echo e(data_get($column, 'headerStyle')); ?>" <?php endif; ?>
                    type="text"
                    class="power_grid <?php echo e($theme->inputClass); ?> <?php echo e(data_get($column, 'headerClass')); ?>"
                    placeholder="Min">
            </div>
            <div class="mt-1">
                <input
                    data-id="<?php echo e($number['field']); ?>"
                    wire:model.debounce.800ms="filters.number_end.<?php echo e(data_get($number, 'dataField')); ?>"
                    wire:input.debounce.800ms="filterNumberEnd('<?php echo e(data_get($number, 'dataField')); ?>',$event.target.value,'<?php echo e(addslashes(data_get($number, 'thousands'))); ?>','<?php echo e(addslashes(data_get($number, 'decimal'))); ?>', '<?php echo e(data_get($number, 'label')); ?>')"
                    <?php if($inline): ?> style="<?php echo e($theme->inputStyle); ?> <?php echo e(data_get($column, 'headerStyle')); ?>" <?php endif; ?>
                    type="text"
                    class="power_grid <?php echo e($theme->inputClass); ?> <?php echo e(data_get($column, 'headerClass')); ?>"
                    placeholder="Max">
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\wamp\www\task-management\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/bootstrap5/filters/number.blade.php ENDPATH**/ ?>