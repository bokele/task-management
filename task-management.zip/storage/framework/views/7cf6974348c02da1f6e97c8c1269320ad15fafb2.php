<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Task')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="container">
                <div class="card">
                    <div class="card-header border-blue text-primary">
                        Add A New Task

                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('tasks.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="project_name" class="form-label">Project Name</label>
                                <select name="project_name" id="project_name" class="form-control <?php echo e($errors->has('project_name') ? 'is-invalid' : ''); ?>">
                                    <option value="">Select a project</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($project->id); ?>" <?php echo e(old('project_name')==$project->id ? 'selected' : ''); ?>><?php echo e($project->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('project_name')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('project_name')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="task_name" class="form-label">Task Name</label>
                                <input type="text" name="task_name" class="form-control <?php echo e($errors->has('task_name') ? 'is-invalid' : ''); ?>" id="task_name" placeholder="Task name" value="<?php echo e(old('task_name')); ?>" />
                                <?php if($errors->has('task_name')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('task_name')); ?></div>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-outline-primary btn-sm float-right">Save</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\wamp\www\task-management\resources\views/tasks/create.blade.php ENDPATH**/ ?>