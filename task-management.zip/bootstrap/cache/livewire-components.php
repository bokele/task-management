<?php return array (
  'project.index-livewire' => 'App\\Http\\Livewire\\Project\\IndexLivewire',
  'project.project-table' => 'App\\Http\\Livewire\\Project\\ProjectTable',
  'task.task-table' => 'App\\Http\\Livewire\\Task\\TaskTable',
);