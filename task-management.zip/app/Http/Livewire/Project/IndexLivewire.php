<?php

namespace App\Http\Livewire\Project;

use Livewire\Component;

class IndexLivewire extends Component
{
    public function render()
    {
        return view('livewire.project.index-livewire');
    }
}
