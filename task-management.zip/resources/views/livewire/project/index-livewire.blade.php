<div>
    {{-- The best athlete wants his opponent at his best. --}}
</div>
